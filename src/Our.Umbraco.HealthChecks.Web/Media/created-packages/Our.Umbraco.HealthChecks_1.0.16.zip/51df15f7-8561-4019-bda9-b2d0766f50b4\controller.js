﻿angular.module("umbraco").controller("Our.Umbraco.HealthChecks.Controller", function ($scope) {
    $('.umb-healthcheck-title').on('click',
        function() {
            alert('clicked');
        });
});